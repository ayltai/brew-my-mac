package ${PACKAGE_NAME};

import android.app.Application;

#parse("File Header.java")
public final class ${NAME} extends Application {
}
