package ${PACKAGE_NAME};

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

#parse("File Header.java")
public final class ${NAME} extends BroadcastReceiver {
    @Override
    public void onReceive(final Context context, final Intent intent) {
    }
}
