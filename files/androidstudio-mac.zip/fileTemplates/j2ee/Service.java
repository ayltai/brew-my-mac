package ${PACKAGE_NAME};

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

#parse("File Header.java")
public final class ${NAME} extends Service {
    @Override
    public IBinder onBind(final Intent intent) {
        return null;
    }
}
