import junit.framework.TestCase;
#parse("File Header.java")
public final class ${NAME} extends TestCase {
  ${BODY}
}