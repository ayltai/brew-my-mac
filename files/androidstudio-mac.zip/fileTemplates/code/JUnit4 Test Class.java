import static org.junit.Assert.*;
#parse("File Header.java")
public final class ${NAME} {
  ${BODY}
}