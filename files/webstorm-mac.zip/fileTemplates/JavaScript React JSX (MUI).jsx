import { makeStyles, Typography, } from '@material-ui/core';
import PropTypes from 'prop-types';
import React from 'react';

export const $NAME = props => {
    const classes = makeStyles(theme => ({
    }))();

    return ();
};

${NAME}.propTypes = {};
