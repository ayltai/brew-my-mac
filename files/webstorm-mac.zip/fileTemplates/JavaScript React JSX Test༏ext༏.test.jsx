import { mount, shallow, } from 'enzyme';
import React from 'react';
import renderer from 'react-test-renderer';

import { $NAME, } from './$NAME';

describe('<$NAME />', () => {
    it('renders correctly', () => {
        expect(renderer.create(
            <$NAME />
        ).toJSON()).toMatchSnapshot();
    });

    it('mounts without error', () => {
        mount(
            <$NAME />
        );
    });
});
