import PropTypes from 'prop-types';
import React from 'react';

export const $NAME = props => {
    return ();
};

$NAME.propTypes = {};
