import React from 'react';

import { $NAME, } from '../components/$NAME';

export default {
    title     : '',
    component : $NAME,
    argTypes  : {
    },
};

const Template = args => <$NAME {...args} />;

export const Basic = Template.bind({});
Basic.args = {
};
